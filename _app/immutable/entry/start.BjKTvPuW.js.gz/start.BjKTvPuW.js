import{a as t}from"../chunks/entry.BhuTSxbJ.js";export{t as start};
