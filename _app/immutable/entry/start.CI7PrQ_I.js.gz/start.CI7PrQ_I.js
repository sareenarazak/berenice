import{a as t}from"../chunks/entry.BpZjKR5_.js";export{t as start};
