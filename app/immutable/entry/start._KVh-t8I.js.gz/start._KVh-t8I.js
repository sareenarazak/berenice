import{a as t}from"../chunks/entry.C3XzyYBE.js";export{t as start};
