import{a as t}from"../chunks/entry.B1MiTr4j.js";export{t as start};
