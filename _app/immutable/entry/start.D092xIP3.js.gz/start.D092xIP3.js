import{a as t}from"../chunks/entry.JadVYk8Q.js";export{t as start};
